﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AracTakibi1647.Views
{
    public partial class AracTakibi : Form
    {
        public AracTakibi()
        {
            InitializeComponent();
        }
    }
}
