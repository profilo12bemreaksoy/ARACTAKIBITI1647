﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AracTakibi1647.Models
{
    [Table("Araclar")]
    internal class Araclarr
    {
        public int Id { get; set; }
        public required string Marka { get; set; }
        public required string Model { get; set; }
        public DateTime ÜretimTarihi { get; set; }
        public double Fiyat { get; set; }
    }
}
