﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace AracTakibi1647.Models
{
    internal class AppDb:DbContext
    {
        public virtual DbSet <Araclarr> Araclar { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=(localdb)\MSSQLLocalDB;IntegratedSecurity=true;AttachDbFileName=|DataDirectory| Db.mdf;").UseLazyLoadingProxies();

        }
    }
}
